/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Lexico;

import java.io.File;

/**
 *
 * @author Carlos
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        File path=new File ("src/Lexico/Lexer.flex");
        String lexer=path.getAbsolutePath()+"";
        generarLexer(lexer);

    }
    public static void generarLexer(String path){
        File file=new File(path);
        jflex.Main.generate(file);
    }
}

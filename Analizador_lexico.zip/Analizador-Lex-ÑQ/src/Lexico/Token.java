/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Lexico;

/**
 *
 * @author Carlos
 */
public enum Token {
    INICIO,SOLDAR,REINICIO,MOV_X,MOV_Y,ARRIBA,ABAJO,
    FIN,LIMPIAR_A,LISTA,PURGAR_A,SEGUIR_LINEA,TEMPERATURA,CALIBRAR,DESACTIVADO,VELOCIDAD,
    MIENTRAST,SI,SINO,OP_REL,OP_ARI,SIMBOLOS,AGRUPACION,
   NUMEROS,IR_,

    
    IDENTIFICADOR, ERROR
}

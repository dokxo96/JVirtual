/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lexico;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.Highlighter;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;

/**
 *
 * @author Diana
 */
public class ide extends JFrameCanvas  {
   
    TextLineNumber lineas;
    final static Color HILIT_COLOR = Color.LIGHT_GRAY;
    DefaultStyledDocument doc;
    private GestionFichero gestionFichero;
    
    List<identificador> tokenslist;
     private String titulo = "Analizador Lexico";
    /**
     * Creates new form ide
     */
    public ide() {
        initComponents();
//        setSize(1003, 567);
//        setLocation(180, 75);
        this.setTitle(titulo);
          final StyleContext cont = StyleContext.getDefaultStyleContext();
        final AttributeSet red = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, Color.RED);
        final AttributeSet Black = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, Color.BLACK);
        final AttributeSet blue = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, Color.blue);
        final AttributeSet green = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, Color.green);
        final AttributeSet DARK_GRAY = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, Color.DARK_GRAY);
        final AttributeSet orange = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, Color.orange);
        final AttributeSet gris = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, Color.LIGHT_GRAY);
        
        doc = new DefaultStyledDocument() {
            public void insertString(int offset, String str, AttributeSet a) throws BadLocationException {
                super.insertString(offset, str, a);
                String text = txtaCodigo.getText(0, getLength());
                int before = findLastNonWordChar(text, offset);
                if (before < 0) {
                    before = 0;
                }
                int after = findFirstNonWordChar(text, offset + str.length());
                int wordL = before;
                int wordR = before;

                while (wordR <= after) {
                    if (wordR == after || String.valueOf(text.charAt(wordR)).matches("\\W")) {

                        if (text.substring(wordL, wordR).matches("(\\W)*(none)")) {
                            setCharacterAttributes(wordL, wordR - wordL, green, false);
                        } else if (text.substring(wordL, wordR).matches("/(.*|\\s)+")) {
                            setCharacterAttributes(wordL, wordR - wordL, gris, false);
                        } else if (text.substring(wordL, wordR).matches("(\\W)*(#|:|=)")) {
                            setCharacterAttributes(wordL, wordR - wordL, red, false);
                        } else if (text.substring(wordL, wordR).matches("(\\W)*()")) {
                            setCharacterAttributes(wordL, wordR - wordL, Black, false);
                        } else if (text.substring(wordL, wordR).matches("(\\W)*(declara|bucle)")) {
                            setCharacterAttributes(wordL, wordR - wordL, DARK_GRAY, false);
                        } else if (text.substring(wordL, wordR).matches("(\\W)*(ciclo|ed|ef|entrada|salida|entrada|salida|motorelect|servo)")) {
                            setCharacterAttributes(wordL, wordR - wordL, blue, false);
                        } else {
                            setCharacterAttributes(wordL, wordR - wordL, Black, false);
                        }
                        wordL = wordR;
                    }
                    wordR++;
                }
            }
        public void remove(int offs, int len) throws BadLocationException {
                super.remove(offs, len);
                String text = txtaCodigo.getText(0, getLength());
                int before = findLastNonWordChar(text, offs);
                if (before < 0) {
                    before = 0;
                }
                int after = findFirstNonWordChar(text, offs);

                if (text.substring(before, after).matches("(\\W)*(function|private)")) {
                    setCharacterAttributes(before, after - before, red, false);
                } else if (text.substring(before, after).matches("(\\W)*(for|while)")) {
                    setCharacterAttributes(before, after - before, blue, false);
                } else if (text.substring(before, after).matches("(\\W)*(if|else)")) {
                    setCharacterAttributes(before, after - before, green, false);
                } else if (text.substring(before, after).matches("(\\W)*(int|string)")) {
                    setCharacterAttributes(before, after - before, orange, false);
                } else if (text.substring(before, after).matches("(\\W)*(>|<)")) {
                    setCharacterAttributes(before, after - before, DARK_GRAY, false);
                } else if (text.substring(before, after).matches("(\\W)*(begin|end)")) {
                    setCharacterAttributes(before, after - before, gris, false);
                } else {
                    setCharacterAttributes(before, after - before, Black, false);
                }

            }
        };
        
        
       
        lineas = new TextLineNumber(txtaCodigo);
        lineas.setCurrentLineForeground(new Color(255, 0, 0));//current line
        lineas.setForeground(new Color(40, 116, 166));//color linea

        jScrollPane4.setRowHeaderView(lineas);
        jScrollPane4.setViewportView(txtaCodigo);  

        
    }
    
    
    
    
    
    private int findLastNonWordChar(String text, int index) {
        while (--index >= 0) {
            if (String.valueOf(text.charAt(index)).matches("\\W")) {
                break;
            }
        }
        return index;
    }
    
    private int findFirstNonWordChar(String text, int index) {
        while (index < text.length()) {
            if (String.valueOf(text.charAt(index)).matches("\\W")) {
                break;
            }
            index++;
        }
        return index;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jToggleButton1 = new javax.swing.JToggleButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu2 = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();
        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu4 = new javax.swing.JMenu();
        jMenu5 = new javax.swing.JMenu();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        jPopupMenu2 = new javax.swing.JPopupMenu();
        jPanel1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtaCodigo = new javax.swing.JTextPane();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtaSalida = new javax.swing.JTextArea();
        MnuBar = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        mitNuevo = new javax.swing.JMenuItem();
        mitAbrir = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();
        mitGuardarComo = new javax.swing.JMenuItem();
        mitSalir = new javax.swing.JMenuItem();
        jMenu6 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();

        jToggleButton1.setText("jToggleButton1");

        jMenu2.setText("File");
        jMenuBar1.add(jMenu2);

        jMenu3.setText("Edit");
        jMenuBar1.add(jMenu3);

        jMenu4.setText("File");
        jMenuBar2.add(jMenu4);

        jMenu5.setText("Edit");
        jMenuBar2.add(jMenu5);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        jPanel4.setBackground(new java.awt.Color(0, 153, 153));

        jLabel4.setFont(new java.awt.Font("Papyrus", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 153, 0));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Consolas", 0, 12)); // NOI18N
        jLabel3.setText("Salir");
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        jLabel5.setBackground(new java.awt.Color(0, 153, 153));
        jLabel5.setFont(new java.awt.Font("Consolas", 0, 12)); // NOI18N
        jLabel5.setText("Analizar");
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        jSeparator3.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jLabel2.setFont(new java.awt.Font("Consolas", 0, 12)); // NOI18N
        jLabel2.setText("Nuevo");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        jSeparator4.setOrientation(javax.swing.SwingConstants.VERTICAL);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(309, 309, 309)
                        .addComponent(jLabel4))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(555, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel5)
                            .addComponent(jLabel3)))
                    .addComponent(jSeparator3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSeparator4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        txtaCodigo.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N
        txtaCodigo.setText("inicio  m_c1:\n\ndec  m_c0 15.65\ndec  m_c1 23.78\n\n \nmov_x  m_c0\nmov_y  m_c1\n\nseguir_linea  1\n\nsoldar $estos son comentarios y no son tomado en cuenta por el compilador\n\n:fin \n");
        jScrollPane4.setViewportView(txtaCodigo);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jTable1.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable1.setEnabled(false);
        jTable1.setGridColor(new java.awt.Color(204, 204, 204));
        jScrollPane3.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 435, Short.MAX_VALUE)
        );

        jPanel2.setBackground(new java.awt.Color(0, 102, 102));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        txtaSalida.setBackground(new java.awt.Color(0, 0, 0));
        txtaSalida.setColumns(20);
        txtaSalida.setForeground(new java.awt.Color(255, 255, 255));
        txtaSalida.setRows(5);
        txtaSalida.setBorder(null);
        jScrollPane2.setViewportView(txtaSalida);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 983, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 185, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane4)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(11, 11, 11)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        MnuBar.setBackground(new java.awt.Color(255, 255, 255));
        MnuBar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jMenu1.setText("Archivo");
        jMenu1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenu1ActionPerformed(evt);
            }
        });

        mitNuevo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        mitNuevo.setText("Nuevo");
        mitNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mitNuevoActionPerformed(evt);
            }
        });
        jMenu1.add(mitNuevo);

        mitAbrir.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        mitAbrir.setText("Abrir");
        mitAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mitAbrirActionPerformed(evt);
            }
        });
        jMenu1.add(mitAbrir);

        jMenuItem1.setText("Guardar");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        mitGuardarComo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_G, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        mitGuardarComo.setText("Guardar como");
        mitGuardarComo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mitGuardarComoActionPerformed(evt);
            }
        });
        jMenu1.add(mitGuardarComo);

        mitSalir.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_MASK));
        mitSalir.setText("Salir");
        mitSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mitSalirActionPerformed(evt);
            }
        });
        jMenu1.add(mitSalir);

        MnuBar.add(jMenu1);

        jMenu6.setText("Tablas de simbolos");

        jMenuItem2.setText("Palabras reservadas");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem2);

        jMenuItem3.setText("Identificadores");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem3);

        MnuBar.add(jMenu6);

        setJMenuBar(MnuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        try {
            probarLexerFile();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        tablaResultado();
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        this.dispose();
    }//GEN-LAST:event_jLabel3MouseClicked

    private void mitSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mitSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_mitSalirActionPerformed

    private void mitAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mitAbrirActionPerformed
    javax.swing.JFileChooser f= new javax.swing.JFileChooser();
        f.showOpenDialog(this);
        fileName=f.getSelectedFile().getName();
        try {
            java.io.FileInputStream fe = new java.io.FileInputStream(fileName); //fe = Flujo de Entrada
            byte b[]=txtaCodigo.getText().getBytes();
            String cad="";
            int c=0;
            while((c=fe.read())!=-1){
              cad=cad+(char)c;
            }
            txtaCodigo.setText(cad);
        } catch (FileNotFoundException ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Error");
        } catch (IOException ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Error");
        }
    }                                                 


    private void guardarArchivoBotonActionPerformed(java.awt.event.ActionEvent evt) {                                                    

    }//GEN-LAST:event_mitAbrirActionPerformed

    private void mitNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mitNuevoActionPerformed
        if(!txtaCodigo.getText().equals("")&&!g)
        if(javax.swing.JOptionPane.showConfirmDialog(this, "¿Desea Guardar los Cambios?")==0){
            if(fileName.equals("")){
                javax.swing.JFileChooser f= new javax.swing.JFileChooser();
                //Tarea filtro
                f.showSaveDialog(this);
                fileName=f.getSelectedFile().getName();
            }
            guardar();
        }//Guardar = si
        txtaCodigo.setText(""); fileName=""; g=false;
    }//GEN-LAST:event_mitNuevoActionPerformed

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        txtaCodigo.setText("");
    }//GEN-LAST:event_jLabel2MouseClicked

    private void mitGuardarComoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mitGuardarComoActionPerformed
       String cmpNombreArchivo="";
        cmpNombreArchivo=showInputDialog(null,"Guardar como:");  
        File fichero = new File(cmpNombreArchivo+".txt");
        PrintWriter writer;
        try {
            writer = new PrintWriter(fichero);
            writer.print(txtaCodigo.getText());
            writer.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ide.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            if (cmpNombreArchivo.equals("")) {
                showMessageDialog(null,"ErrorArchivo vacio");
            } else {
                JFileChooser jfile = new JFileChooser();
                jfile.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                int respuesta = jfile.showOpenDialog(this);
                if (respuesta == JFileChooser.APPROVE_OPTION) {
                    gestionFichero.guardarFichero(txtaCodigo.getText(), cmpNombreArchivo);
                }
            }
        } catch (Exception e) {
            ;
        }
    }//GEN-LAST:event_mitGuardarComoActionPerformed

    private void jMenu1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenu1ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jMenu1ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
           if(!txtaCodigo.getText().equals("")&&!g)
            if(javax.swing.JOptionPane.showConfirmDialog(this, "¿Desea Guardar los Cambios?")==0){
                if(fileName.equals("")){
                    javax.swing.JFileChooser f= new javax.swing.JFileChooser();
                    //Tarea filtro 
                    f.showSaveDialog(this);
                    fileName=f.getSelectedFile().getName();
                }
                guardar();
            }//Guardar = si
        txtaCodigo.setText(""); fileName=""; g=false;
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem3ActionPerformed
  public void probarLexerFile() throws IOException {
        int contIDs = 0;
        tokenslist = new LinkedList<identificador>();
        File fichero = new File("fichero.txt");
        PrintWriter writer;
        try {
            writer = new PrintWriter(fichero);
            writer.print(txtaCodigo.getText());
            writer.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ide.class.getName()).log(Level.SEVERE, null, ex);
        }
        Reader reader = new BufferedReader(new FileReader("fichero.txt"));
        Lexer lexer = new Lexer(reader);
        String resultado = "";
        while (true) {
            Token token = lexer.yylex();
            if (token == null) {
                for (int i = 0; i < tokenslist.size(); i++) {
                    System.out.println(tokenslist.get(i).nombre + "=" + tokenslist.get(i).ID);
                }
                txtaSalida.setText(resultado);
                return;
            }
            switch (token) {
                
                
                case INICIO: {
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Palabra Reservada";
                    tokenslist.add(tokenitem);
                    break;
                }                
                case SOLDAR: {
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Palabra Reservada";
                    tokenslist.add(tokenitem);
                    break;
                }
                case REINICIO: {
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Palabra Reservada";
                    tokenslist.add(tokenitem);
                    break;
                }
                case MOV_X: {
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Palabra Reservada";
                    tokenslist.add(tokenitem);
                    break;
                }
                case MOV_Y: {
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Palabra Reservada";
                    tokenslist.add(tokenitem);
                    break;
                }
                case ARRIBA: {
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Palabra Reservada";
                    tokenslist.add(tokenitem);
                    break;
                }
                case LIMPIAR_A: {
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Palabra Reservada";
                    tokenslist.add(tokenitem);
                    break;
                }
                case LISTA: {
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Palabra Reservada";
                    tokenslist.add(tokenitem);
                    break;
                }
                case FIN: {
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Palabra Reservada";
                    tokenslist.add(tokenitem);
                    break;
                }
                case IR_: {
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Palabra Reservada";
                    tokenslist.add(tokenitem);
                    break;
                }
                case PURGAR_A: {
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Palabra Reservada";
                    tokenslist.add(tokenitem);
                    break;
                }
                case SEGUIR_LINEA: {
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Palabra Reservada";
                    tokenslist.add(tokenitem);
                    break;
                }
                case DESACTIVADO: {
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Palabra Reservada";
                    tokenslist.add(tokenitem);
                    break;
                }
                case VELOCIDAD: {
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Palabra Reservada";
                    tokenslist.add(tokenitem);
                    break;
                }
                case MIENTRAST: {
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Palabra Reservada";
                    tokenslist.add(tokenitem);
                    break;
                }
                case SI: {
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Palabra Reservada";
                    tokenslist.add(tokenitem);
                    break;
                }
                case SINO: {
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Palabra Reservada";
                    tokenslist.add(tokenitem);
                    break;
                }                
                case NUMEROS:{
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "NUMERO";
                    tokenslist.add(tokenitem);
                    break;
                }                                                
                case IDENTIFICADOR: {
                    contIDs++;
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "<IDENTIFICADOR" + contIDs + "> ";
                    tokenslist.add(tokenitem);
                    break;
                }
                
                case OP_REL: {
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Operador Relacional";
                    tokenslist.add(tokenitem);
                    break;
                }
                case OP_ARI: {
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Operador Aritmetico";
                    tokenslist.add(tokenitem);
                    break;
                }
                  case SIMBOLOS:{
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Simbolos";
                    tokenslist.add(tokenitem);
                    break;
                }
                   case AGRUPACION:{
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Simbolos de Agrupacion";
                    tokenslist.add(tokenitem);
                    break;
                }
                   case TEMPERATURA:{
                    identificador tokenitem = new identificador();
                    tokenitem.nombre = lexer.lexeme;
                    tokenitem.titulo = "Palabra Reservada";
                    tokenslist.add(tokenitem);
                    break;
                }
                
                case ERROR:
                    resultado = resultado + "Error, linea"+(lexer.yyline+1)+", simbolo no pertenece a lenguaje  "+lexer.lexeme+"\n";
                    break;

                default:
                    resultado = resultado + "<" + lexer.lexeme+ "> ";
            }
        }
    }
  public void tablaResultado() {
        Object[][] matriz = new Object[tokenslist.size()][2];
        for (int i = 0; i < tokenslist.size(); i++) {
            matriz[i][0] = tokenslist.get(i).nombre;
            matriz[i][1] = tokenslist.get(i).titulo;
        }
        jTable1.setModel(new javax.swing.table.DefaultTableModel(matriz,
                new String[]{
                    "Nombre", "Token/No.ID"
                }
        ));
    }
    
    
   
    
    private void guardar(){
        try {
            java.io.FileOutputStream fs = new java.io.FileOutputStream(fileName,true); //fs = Flujo de Salida
            byte b[]=txtaCodigo.getText().getBytes();
            fs.write(b);
        } catch (FileNotFoundException ex) {
            javax.swing.JOptionPane.showMessageDialog(this, ex.getMessage());
        } catch (IOException ex) {
            javax.swing.JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }
    private String fileName="";
    private boolean g=false;
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ide.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ide.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ide.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ide.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ide().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuBar MnuBar;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JPopupMenu jPopupMenu2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JTable jTable1;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JMenuItem mitAbrir;
    private javax.swing.JMenuItem mitGuardarComo;
    private javax.swing.JMenuItem mitNuevo;
    private javax.swing.JMenuItem mitSalir;
    private javax.swing.JTextPane txtaCodigo;
    private javax.swing.JTextArea txtaSalida;
    // End of variables declaration//GEN-END:variables

    private void cmpNombreArchivo(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
